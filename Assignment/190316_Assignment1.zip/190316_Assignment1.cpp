#include <iostream>
#include <fstream>
#include <queue>
#include <vector>

using namespace std;

// Custom Class
// record: Record of the database
// run_ptr: Run no of a given subphase of a given merge pass.
// block_ptr: Block no of the given run
// record_ptr: Record no of the given block
class Record
{
    int record;
    int run_ptr;
    int block_ptr;
    int record_ptr;

public:
    Record(int record, int run_ptr, int block_ptr, int record_ptr)
    {
        this->record = record;
        this->run_ptr = run_ptr;
        this->block_ptr = block_ptr;
        this->record_ptr = record_ptr;
    }
    int get_record() const { return record; }
    int get_run_ptr() const { return run_ptr; }
    int get_block_ptr() const { return block_ptr; }
    int get_record_ptr() const { return record_ptr; }
};

// Custom comparator that compares two "Record" objects on
// the basis of "record"
class CustomComparator
{
public:
    int operator()(const Record &p1, const Record &p2)
    {
        return p1.get_record() > p2.get_record();
    }
};

// Partition function of QuickSort
int partition(int *arr, int l, int h)
{
    int p = l + rand() % (h - l + 1);
    swap(arr[l], arr[p]);

    int i = l - 1;
    int j = h + 1;
    int ele = arr[l];

    while (true)
    {
        do
        {
            i++;
        } while (arr[i] < ele);

        do
        {
            j--;
        } while (arr[j] > ele);

        if (i >= j)
            return j;
        swap(arr[i], arr[j]);
    }
}

void quicksort(int *arr, int l, int h)
{
    while (l < h)
    {
        int p = partition(arr, l, h);
        if ((p - l + 1) <= (h - p))
        {
            quicksort(arr, l, p);
            l = p + 1;
        }
        else
        {
            quicksort(arr, p + 1, h);
            h = p;
        }
    }
}

void external_mergesort(int *records, int m, int b, int n, int k)
{
    // Input Validatiom
    if (m <= 2)
    {
        ofstream fout;
        fout.open("output.txt");
        fout << "Number of blocks in memory must be atleast 3 for the algorithm to work\n";
        fout.close();
        cout << "Number of blocks in memory must be atleast 3 for the algorithm to work\n";
        return;
    }
    else if (k > b)
    {
        ofstream fout;
        fout.open("output.txt");
        fout << "Size of a disk block should be atleast larger tham disk of each record\n";
        fout.close();
        cout << "Size of a disk block should be atleast larger tham disk of each record\n";
        return;
    }

    // Declase Output variables
    int num_seeks = 0, num_transfers = 0, worst_case_seeks = 0;
    int num_merge_passes = 0;

    // ------------------
    // Create Sorted Runs
    // ------------------
    int total_records_block = b / k;                     // No of records in a block
    int total_records_m_block = total_records_block * m; // No of records in m blocks
    int total_blocks = n % total_records_block == 0 ? n / total_records_block : n / total_records_block + 1;

    cout << "Starting to create sorted runs..........\n";
    for (int i = 0; i < n; i += total_records_m_block)
    {
        if (i + total_records_m_block - 1 < n)
        {
            quicksort(records, i, i + total_records_m_block - 1);
            num_transfers += 2 * m;
        }
        else
        {
            quicksort(records, i, n - 1);
            num_transfers += 2 * ((n - i) % total_records_block == 0 ? (n - i) / total_records_block : (n - i) / total_records_block + 1);
        }
        num_seeks += 2;
        worst_case_seeks += 2;
    }

    int blocks_in_run = m; // Initial no of blocks in each run
    int num_runs = total_blocks % blocks_in_run == 0 ? total_blocks / blocks_in_run : total_blocks / blocks_in_run + 1;
    // Initial no of runs

    cout << num_runs << " Sorted runs created\n";

    ofstream fout_final;
    fout_final.open("output_stats.txt");

    ofstream fout;
    fout.open("output_sorted_run.txt");

    fout_final << "Cost after initial sorted run phase: " << num_seeks << " Seeks and " << num_transfers << " Transfers.\n";
    fout_final << "---------------------------------------------------------------------------------------------------\n\n";
    for (int i = 0; i < n; i++)
    {
        fout << records[i] << "\n";
    }
    fout.close();

    // -----------
    // (m-1) - way Merge
    // -----------
    int buffer[total_records_block];
    int buffer_count = 0;

    priority_queue<Record, vector<Record>, CustomComparator> pq; // Min Priority Queue maintains "min" of each record
                                                                 // of each block of m-1 runs. This leads to time
                                                                 // optimization while merging.

    int write_back_counter; // Counter used to index records array while writing back
    int sub_phase_counter;  // Counter for each sub phase of a merge pass.
    int disk_head;          // Head of disk read write arm

    vector<vector<vector<int>>> memory(m - 1);    // This 3D array stores memory of m-1 runs from records array, 
                                                  // merging is done and then written back to records array
    vector<vector<int>> v_blocks_in_run;
    vector<int> v_records_in_block;

    while (num_runs >= m)
    {
        cout << "Starting Merge Pass:" << num_merge_passes + 1 << "..........\n";
        write_back_counter = 0;
        sub_phase_counter = 0;

        fout.open("output_merge_pass" + to_string(num_merge_passes + 1) + ".txt");
        for (int read_counter = 0; read_counter < n; sub_phase_counter++)
        {
            int i, j, k;
            memory.clear();
            for (i = 0; i < m - 1 && read_counter < n; i++)
            {
                v_blocks_in_run.clear();
                for (j = 0; j < blocks_in_run && read_counter < n; j++)
                {
                    v_records_in_block.clear();
                    for (k = 0; k < total_records_block && read_counter < n; k++)
                    {
                        v_records_in_block.push_back(records[read_counter++]);
                        // memory[i][j][k] = records[read_counter++];
                    }
                    v_blocks_in_run.push_back(v_records_in_block);
                    num_transfers += 2;
                    worst_case_seeks += 2;
                    if (j == 0)
                    {
                        disk_head = i;
                        num_seeks += 2;
                    }
                }
                memory.push_back(v_blocks_in_run);
            }

            for (int i1 = 0; i1 < i; i1++)
            {
                pq.push(Record(memory[i1][0][0], i1, 0, 0)); // Add first record of first block of (m-1) runs to
                                                             // Priority Queue
            }

            while (!pq.empty())
            {
                Record p = pq.top();
                pq.pop();
                buffer[buffer_count++] = p.get_record();
                int i1 = p.get_run_ptr();
                int j1 = p.get_block_ptr();
                int k1 = p.get_record_ptr();

                if (i1 < (i - 1)) // This if-else logic decides which record to put into Priority Queue next
                {
                    if (k1 < total_records_block - 1)
                    {
                        pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                    }
                    else if (j1 < blocks_in_run - 1)
                    {
                        pq.push(Record(memory[i1][j1 + 1][0], i1, j1 + 1, 0));
                        if (i1 != disk_head)
                        {
                            disk_head = i1;
                            num_seeks += 2;
                        }
                    }
                }
                else
                {
                    if (j1 < (j - 1))
                    {
                        if (k1 < total_records_block - 1)
                        {
                            pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                        }
                        else
                        {
                            pq.push(Record(memory[i1][j1 + 1][0], i1, j1 + 1, 0));
                            if (i1 != disk_head)
                            {
                                disk_head = i1;
                                num_seeks += 2;
                            }
                        }
                    }
                    else if (k1 < (k - 1))
                    {
                        pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                    }
                }

                if (buffer_count == total_records_block) // Write back into records array when buffer is full
                {
                    while (buffer_count != 0)
                    {
                        records[write_back_counter++] = buffer[total_records_block - buffer_count];
                        buffer_count--;
                    }
                }
            }
            for (int t = 0; t < buffer_count; t++) // Write back any leftover records in buffer back to records array
            {
                records[write_back_counter++] = buffer[t];
            }
            buffer_count = 0;

            fout_final << "Cost after sub-phase " << sub_phase_counter + 1 << " of Merge Pass " << num_merge_passes + 1 << ": " << num_seeks << " Seeks, " << worst_case_seeks << " Seeks in worst case and " << num_transfers << " Transfers.\n";
        }

        // After each merge pass, size of a run becomes previous size*(m-1) due to merging. Thus, num of runs are also updated
        blocks_in_run = blocks_in_run * (m - 1);
        num_runs = total_blocks % blocks_in_run == 0 ? total_blocks / blocks_in_run : total_blocks / blocks_in_run + 1;

        num_merge_passes++;
        fout_final << "...........................................................................................\n\n";
        for (int i = 0; i < n; i++)
        {
            fout << records[i] << "\n";
        }
        fout.close();
        cout << "Finished Merge Pass:" << num_merge_passes << "\n";
    }

    // One last merge pass to finally sort the records
    if (num_runs > 1)
    {
        cout << "Starting Merge Pass:" << num_merge_passes + 1 << "..........\n";
        write_back_counter = 0;
        sub_phase_counter = 0;

        fout.open("output_merge_pass" + to_string(num_merge_passes + 1) + ".txt");
        for (int read_counter = 0; read_counter < n; sub_phase_counter++)
        {
            memory.clear();
            int i, j, k;
            for (i = 0; i < num_runs && read_counter < n; i++)
            {
                v_blocks_in_run.clear();
                for (j = 0; j < blocks_in_run && read_counter < n; j++)
                {
                    v_records_in_block.clear();
                    for (k = 0; k < total_records_block && read_counter < n; k++)
                    {
                        v_records_in_block.push_back(records[read_counter++]);
                        // memory[i][j][k] = records[read_counter++];
                    }
                    v_blocks_in_run.push_back(v_records_in_block);
                    num_transfers += 2;
                    worst_case_seeks += 2;
                    if (j == 0)
                    {
                        disk_head = i;
                        num_seeks += 2;
                    }
                }
                memory.push_back(v_blocks_in_run);
            }

            for (int i1 = 0; i1 < i; i1++)
            {
                pq.push(Record(memory[i1][0][0], i1, 0, 0));
            }

            while (!pq.empty())
            {
                Record p = pq.top();
                pq.pop();
                buffer[buffer_count++] = p.get_record();
                int i1 = p.get_run_ptr();
                int j1 = p.get_block_ptr();
                int k1 = p.get_record_ptr();

                if (i1 < (i - 1))
                {
                    if (k1 < total_records_block - 1)
                    {
                        pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                    }
                    else if (j1 < blocks_in_run - 1)
                    {
                        pq.push(Record(memory[i1][j1 + 1][0], i1, j1 + 1, 0));
                        if (i1 != disk_head)
                        {
                            disk_head = i1;
                            num_seeks += 2;
                        }
                    }
                }
                else
                {
                    if (j1 < (j - 1))
                    {
                        if (k1 < total_records_block - 1)
                        {
                            pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                        }
                        else
                        {
                            pq.push(Record(memory[i1][j1 + 1][0], i1, j1 + 1, 0));
                            if (i1 != disk_head)
                            {
                                disk_head = i1;
                                num_seeks += 2;
                            }
                        }
                    }
                    else if (k1 < (k - 1))
                    {
                        pq.push(Record(memory[i1][j1][k1 + 1], i1, j1, k1 + 1));
                    }
                }

                if (buffer_count == total_records_block)
                {
                    while (buffer_count != 0)
                    {
                        records[write_back_counter++] = buffer[total_records_block - buffer_count];
                        buffer_count--;
                    }
                }
            }
            for (int t = 0; t < buffer_count; t++)
            {
                records[write_back_counter++] = buffer[t];
            }
            buffer_count = 0;

            fout_final << "Cost after sub-phase " << sub_phase_counter + 1 << " of Merge Pass " << num_merge_passes + 1 << ": " << num_seeks << " Seeks, " << worst_case_seeks << " Seeks in worst case and " << num_transfers << " Transfers.\n";
        }
        num_merge_passes++;

        fout_final << "............................................................................................\n\n";
        for (int i = 0; i < n; i++)
        {
            fout << records[i] << "\n";
        }
        fout.close();
        cout << "Finished Merge Pass:" << num_merge_passes << "\n";
    }

    // fout.open("output_final.txt");
    fout_final << "Total number of Disk Seeks: " << num_seeks << "\n";
    fout_final << "Total Seeks in worst case: " << worst_case_seeks << "\n";
    fout_final << "Total number of Disk Transfers: " << num_transfers << "\n";
    fout_final << "Total number of Merge Passes: " << num_merge_passes << "\n";
    fout_final << "----------------------------------------------------------------------------------------------\n\n";
    fout_final.close();

    cout << "All outputs written to corrs. output files.\n";
}

int main(int argc, char *argv[])
{
    string input_file = argv[1];
    int m = stoi(argv[2]); // Number of Blocks
    int k = stoi(argv[3]); // Size of each key
    int n = stoi(argv[4]); // Total Keys
    int b = stoi(argv[5]); // Disk Block Size

    // string input_file = "input2.txt";
    // int m = 10;
    // int k = 8;
    // int n = 1000000;
    // int b = 1024;

    ifstream fin;
    fin.open(input_file);

    int *records = (int *)malloc(n * sizeof(int)); // Array to store individual records of the database table
    for (int i = 0; i < n; i++)
    {
        fin >> records[i]; // Here all the records are read from db table and all the process is simulated
    }                      // in memory insteda of doing read-write againa and again

    external_mergesort(records, m, b, n, k);
}