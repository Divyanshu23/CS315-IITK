```
make all: Compile and Run code for the default input file and parameters
```

```
make compile: Compile the cpp file to an executable
```

```
make clean: Clean up the directory of all output files
```

### Edit the make file accordingly for input file change or parameter change